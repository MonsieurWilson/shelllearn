#!/bin/sh

if [ "$#" != "1" ]; then
	echo "Usage: $0 <cpio_list>"
	exit
fi

if [ ! -s $1 ] ; then
	echo "File $1 not exist!"
	exit
fi

AWK_LDD='{
	if ($1 == "#") { next }
	if (NF == 6 && $1 == "file") {
		print $3
	}
}'

DEP=initramfs_data.d
echo -n "${1}: files.cfg " > ${DEP}
for f in `awk "${AWK_LDD}" $1`; do
	echo -n ${f}" " >> ${DEP}
done

