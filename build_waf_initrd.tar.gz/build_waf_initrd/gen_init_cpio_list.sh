#!/bin/sh

export PATH="/sbin:/usr/sbin:"${PATH}

if [ "$#" != "2" ]; then
	echo "Usage: $0 <cpio_list> <new_list>"
	exit
fi

if [ ! -s $1 ] ; then
	echo "File $1 not exist!"
	exit
fi

# test new list file, must be regular file
if [ -s $2 ] ; then
	[ -f $2 ] && {
		read -s -n 1 -p " File $2 already exist, delete it? (n) " REPLY
		if [[ "$?" = "0" && ( "${REPLY}" = "y" || "${REPLY}" = "Y" ) ]] ; then
			echo
			rm -fr $2
		else # timeout or retry
			echo
			exit
		fi
	} || {
		echo "File $2 already exist, but is not a regular file!"
		exit
	}
fi

# void LoopDir(src_dir, dst_dir, dst_file, uid, gid)
# 
#    Loop over src_dir, output file list to dst_file
#
LoopDir()
{
	[ $# -lt 3 ] && return
	[ -d $1 ] || return
	[ -f $3 ] || return
	for f in `ls -a ${1}`; do
		[ -d ${1}/${f} ] && {
			if [ "${f}" != ".svn" -a "${f}" != "." -a "${f}" != ".." ] ; then
				echo "dir ${2}/${f} $(stat -c "%a" ${1}/${f}) ${4:-0} ${5:-0}" >> ${3}
				LoopDir ${1}/${f} ${2}/${f} ${3} ${4:-0} ${5:-0}
			fi
		} || {
			[ ${f%.*}.pyo != ${f} ] && { # remove *.pyo
				[ -L ${1}/${f} ] && {
					echo "slink ${2}/${f} $(readlink ${1}/${f}) $(stat -c "%a" ${1}/${f}) ${4:-0} ${5:-0}" >> ${3}
				} || {
					echo "file ${2}/${f} ${1}/${f} $(stat -c "%a" ${1}/${f}) ${4:-0} ${5:-0}" >> ${3}
				}
			}
		}
	done
}

# awk script to get executable files, and pam modules
AWK_EXEC='{
	if ($1 == "#") { next }
	if (NF == 6 && $1 == "file") {
		if ($2 ~ /^\/bin\// \
			|| $2 ~ /^\/sbin\// \
			|| $2 ~ /^\/lib\/security\// \
			|| $2 ~ /^\/usr\/local\/bin\//) {
			print $3
		}
	}
}'

# awk script to analyse ldd result
AWK_GETLIB='{
	if (NF == 4 && $1 ~ /^lib/ && $2 == "=>") {
		if ($3 ~ /^\/lib64\// \
			|| $3 ~ /^\/usr\/lib64\// ) {
			sub(/lib64/, "lib", $3)
		}
		print $3
	}
}'

# awk script to analyse pam modules
AWK_GETPAM='{
	if ($1 == "#" || NF < 3) { next }
	if ($3 ~ /pam/) print $3
	if ($4 ~ /pam/) print $4
}'


CONFIG_FILE=files.cfg

# executable programs to be included
[ -f ${CONFIG_FILE} ] && {
	source ./files.cfg
	# TODO test PROGRAMS variable
} || {
	echo "No config_file exist!"
	exit
}

touch $2

while read line ; do
	# skip comments and blank lines
	[[ ${line}\# == \#* ]] && continue
	case ${line} in
	file*)
		realfile=$(echo $line|awk '{print $3;}')
		[ -f ${realfile} ] && {
			echo ${line} >> $2
		} || {
			echo "WARNING: ${realfile} not exist!"
		}
		;;
	*)
		echo ${line} >> $2
		;;
	esac
done < $1

HARDWARE=$(uname -m)

case "${HARDWARE}" in
	"x86_64")
		GRUB_DIR="/lib/grub/x86_64-pc"
		echo "# /lib, /lib32, /lib64" >> $2
		echo "dir /lib32 0755 0 0" >> $2
		echo "dir /lib64 0755 0 0" >> $2
		echo "slink /lib lib64 0755 0 0" >> $2
		echo "slink /usr/lib32 ../lib32 0755 0 0" >> $2
		echo "slink /usr/lib64 ../lib64 0755 0 0" >> $2
		echo "file /lib32/ld-linux.so.2 /lib32/ld-linux.so.2 0755 0 0" >> $2
		echo "slink /lib64/ld-linux.so.2 /lib32/ld-linux.so.2 0755 0 0" >> $2
		echo "file /lib64/ld-linux-x86-64.so.2 /lib64/ld-linux-x86-64.so.2 0755 0 0" >> $2
		for nss in files compat dns; do
			echo "file /lib32/libnss_${nss}.so.2 /lib32/libnss_${nss}.so.2 0755 0 0" >> $2
			echo "file /lib64/libnss_${nss}.so.2 /lib64/libnss_${nss}.so.2 0755 0 0" >> $2
		done
	;;
	
	i[3456]86)
		GRUB_DIR="/lib/grub/i386-pc"
		echo "# /lib" >> $2
		echo "dir /lib 0755 0 0" >> $2
		echo "file /lib/ld-linux.so.2 /lib/ld-linux.so.2 0755 0 0" >> $2
		for nss in files compat dns; do
			echo "file /lib/libnss_${nss}.so.2 /lib/libnss_${nss}.so.2 0755 0 0" >> $2
		done
	;;

	*)
		echo "Unsupported hardware!"
		exit 1
esac

[ -f etc/pam.conf -a -f etc/pam.d/other ] && {
	echo "WARNING: pam.conf will be ignored if pam.d exist!"
}

[ -f etc/pam.conf -o -f etc/pam.d/other ] && {
	# /lib/security: pam modules
	echo "dir /lib/security 0755 0 0" >> $2
	PAM_CONFIG=etc/pam.conf
	[ -f etc/pam.d/other ] && PAM_CONFIG=etc/pam.d/*
	PAM_MODULES=$(cat ${PAM_CONFIG} | awk "${AWK_GETPAM}" | sort | uniq)
	for module in ${PAM_MODULES}; do
		# TODO module could be in lib32 or other directory
		echo "file /lib/security/${module} /lib/security/${module} 0755 0 0" >> $2
	done
}

[ -f etc/ssh/sshd_config ] && {
	# sftp server in /lib/misc
	echo "dir /lib/misc 0755 0 0" >> $2
	echo "file /lib/misc/sftp-server /usr/lib/misc/sftp-server 0755 0 0" >> $2
}

FILES=${FILES}" "$(awk "${AWK_EXEC}" $2)

# construct executable programs list, PROGRAMS from files.cfg
for f in ${PROGRAMS} ; do
	file=$(which ${f}) || continue
	[ -L ${file} ] && {
		link=$(readlink ${file})
		[ ${link:0:1} == '/' ] && {
			file=${link}
		} || {
			file=$(dirname ${file})/${link}
		}
	}
	FILES=${FILES}" ${file}"
	echo -n "file " >> $2
	if [[ ${file%sbin/*} != ${file} ]] ; then
		echo -n "/sbin/" >> $2
	elif [[ ${file%bin/*} != ${file} ]] ; then
		echo -n "/bin/" >> $2
	fi
	echo ${f} ${file} $(stat -c "%a" ${file}) 0 0 >> $2
done

LIBRARIES=$(ldd ${FILES} | awk "${AWK_GETLIB}" | sort | uniq)
for lib in $LIBRARIES; do
	if [[ ${lib} =~ "lib32" ]]; then
		echo "file /lib32/"$(basename ${lib}) ${lib} 0755 0 0 >> $2
	else
		echo "file /lib/"$(basename ${lib}) ${lib} 0755 0 0 >> $2
	fi
done

# TODO not exact match
if [[ ${FILES} =~ "grub" ]]; then
	# grub files
	echo "# grub files" >> $2
	echo "dir /lib/grub 0755 0 0" >> $2
	echo "dir ${GRUB_DIR} 0755 0 0" >> $2
	for f in $(ls ${GRUB_DIR}) ; do
		file=${GRUB_DIR}/${f}
		echo "file" ${file} ${file} $(stat -c "%a" ${file}) 0 0 >> $2
	done
fi

if [ -s local.sh ] ; then
	source local.sh
fi
